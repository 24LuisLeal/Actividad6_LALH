import Foundation

infix operator +++
func +++(a:Int, b:Int)->Int{
    //Resutlado total es igual al número base que recibimos por parámetro 
    var result = a
    //Valor de la potencia
    var pown = b
    //Mientras la potencia sea mayor a 1
    while pown > 1{
        //El resultado lo multiplicamos por el número base
        result = result * a
        //Restamos una unidad para se vaya reduciendo la variable pown y salir del ciclo
        pown -= 1
    }
    return result
}
//Asignamos valores
let base = 4
let pown = 2
//El valor de 4 elevado al cuadrado
let result = base +++ pown 
print(result)//16
//----------------------------------------------------------------------------------

prefix operator |>

prefix func |>(numbers: [Int]){
    var myArray = numbers
    myArray.sort()
}

var numbers: [Int] = [2,5,3,4]

print(|>numbers)

//----------------------------------------------------------------------------------

let numbers = [2,5,3,4]

class Numbers{
    var arrayNumbers:[Int]
    init(a: [Int]){
        self.arrayNumbers = a
    }
    subscript(idx:Int)->Int{
        get{
            return arrayNumbers[idx] 
        }
        set(newValue){
            arrayNumbers[idx] = newValue 
        }
    }
}

let myNumbers = Numbers(a: numbers)
print(myNumbers[0] * myNumbers[2])

//----------------------------------------------------------------------------------

let myCollection = [1:"A",2:"B",3:"C"]

func valueExist(idx:Int){
    guard let exist = myCollection[idx] else{
        print("No existe")
        return
    }
    print("Existe \(exist)")
}

print(valueExist(idx:5))
print(myCollection[5])